# Auto Apply Job Bot 🤖

This AI bot automatically applies to jobs on platforms like Naukri, LinkedIn, Monster, and Indeed.

## Features
- Upload multiple resumes
- Auto-fill job filters (role, location, salary, experience)
- Automatically apply to jobs
- Logs job application history
- Streamlit UI

## How to Run

```bash
git clone https://github.com/Anuuuuuuu18/auto-apply-job-bot.git
cd auto-apply-job-bot
pip install -r requirements.txt
streamlit run app.py
```

## Author
Built by [Anuuuuuuu18](https://github.com/Anuuuuuuu18)
