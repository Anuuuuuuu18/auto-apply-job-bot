import streamlit as st
from utils import extract_resume_text, extract_contact_info
from naukri_bot import naukri_auto_apply

st.title("Auto Job Apply Bot")

with st.form("job_form"):
    role = st.text_input("Job Role")
    experience = st.number_input("Years of Experience", min_value=0)
    salary = st.number_input("Expected Salary (LPA)", min_value=0)
    city = st.text_input("City")
    country = st.text_input("Country")
    num_jobs = st.number_input("Number of Jobs to Apply", min_value=1, max_value=20)
    resume = st.file_uploader("Upload Resume (PDF)", type=["pdf"])
    submit = st.form_submit_button("Apply")

if submit and resume:
    with open("uploaded_resume.pdf", "wb") as f:
        f.write(resume.getbuffer())
    resume_text = extract_resume_text("uploaded_resume.pdf")
    contact_info = extract_contact_info(resume_text)
    naukri_auto_apply(role, experience, salary, city, country, num_jobs, "uploaded_resume.pdf")
    st.success("Job applications sent successfully!")
